# rinex2

Things that I build for RINEX2 data

- teqcgnuplot: Using Gnuplot v6.0.3 to plot various TEQC qc results in Windows.
